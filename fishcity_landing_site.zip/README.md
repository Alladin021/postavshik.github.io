# FishCity Landing Page (Прототип)

## Как опубликовать на GitHub Pages
1. Создай репозиторий на GitHub (например, username.github.io).
2. Загрузите все файлы из этой папки через Upload Files или git.
3. Включи Pages: Settings → Pages → Branch: main → /root.
4. Сайт будет доступен по https://username.github.io/

## Настройка
- Замени пустые картинки в assets/img на реальные изображения.
- Измени контактные данные в разделе "Контакты".
