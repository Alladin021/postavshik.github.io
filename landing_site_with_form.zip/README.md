# Landing Page с формой обратной связи

## 🚀 Как пользоваться
1. В файле index.html замените `youremail@example.com` и номер телефона на свои.
2. Зарегистрируйтесь на [Formspree](https://formspree.io/) (бесплатно).
3. Создайте форму и получите ваш `form_id`.
4. В `index.html` замените `your_form_id` на реальный ID.
5. Загрузите сайт на GitHub Pages (см. инструкцию в предыдущей версии).
